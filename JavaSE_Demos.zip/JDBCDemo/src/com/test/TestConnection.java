package com.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
public class TestConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Class.forName("oracle.jdbc.OracleDriver");
			System.out.println("Driver Register Success");
			String url="jdbc:oracle:thin:@localhost:1521:xe";
			String user="system";
			String pass="orcl11g";
			Connection con=DriverManager.getConnection(url,user,pass);
			System.out.println("connection success");
			Statement stmt=con.createStatement();
			String qry="select empid,empname,empsal from emp_tbl";
			ResultSet rst=stmt.executeQuery(qry);
			while(rst.next()){
				int id=rst.getInt("empid");
				String empnam=rst.getString("empname");
				int empsalary=rst.getInt("empsal");
				System.out.println(id+" "+empnam+" "+empsalary);
			}
			con.close();
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver not found");
		}
		catch (SQLException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		
	}

}
