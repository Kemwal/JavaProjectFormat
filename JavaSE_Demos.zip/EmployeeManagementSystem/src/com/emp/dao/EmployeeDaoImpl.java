package com.emp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.emp.bean.EmployeeBean;
import com.emp.exception.EmployeeException;
import com.emp.util.DBConnection;

public class EmployeeDaoImpl implements EmployeeDao {
	int id = 0;

	public int generateEmployeeId() {
		Connection con = DBConnection.getConnection();
		String qry = "select emp_empid_sequence.nextval from dual";
		Statement stmt;
		try {
			stmt = con.createStatement();
			ResultSet rst = stmt.executeQuery(qry);
			rst.next();
			id = rst.getInt(1);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return (id);
	}

	@Override
	public int addEmployee(EmployeeBean bean) throws EmployeeException {

		Connection con = DBConnection.getConnection();

		int id = 0;

		String cmd = "insert into emp_tbl(empid,empname,empsal) values(?,?,?)";
		PreparedStatement pstmt;
		try {
			id = generateEmployeeId();
			pstmt = con.prepareStatement(cmd);

			pstmt.setInt(1,id);
			pstmt.setString(2, bean.getEmployeeName());
			pstmt.setInt(3, bean.getEmployeeSalary());
			pstmt.executeUpdate();
		} catch (SQLException e) {
			throw new EmployeeException("Unable to insert");
		}

		return id;
	}

}
