package com.test;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class TestInsert {
	
		public static void main(String[] args) {
			
			
			try {
				Class.forName("oracle.jdbc.OracleDriver");
				System.out.println("Driver Register Success");
				String url="jdbc:oracle:thin:@localhost:1521:xe";
				String user="system";
				String pass="orcl11g";
				Connection con=DriverManager.getConnection(url,user,pass);
				System.out.println("connection success");
				con.setAutoCommit(false);
				String cmd="insert into emp_tbl(empid,empname,empsal) values(emp_empid_sequence.nextval,?,?)";
				PreparedStatement pstmt=con.prepareStatement(cmd);
				//pstmt.setInt(1,1006);
				pstmt.setString(1,"sona hai");
				pstmt.setInt(2, 10);
				int n=pstmt.executeUpdate();
				System.out.println("Number of records="+n);
				System.out.println("1.commit    2.Rollback");
				Scanner sc=new Scanner(System.in);
				int option=sc.nextInt();
				if(option==1)
					con.commit();
				else
					con.rollback();
				con.close();
				
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				System.out.println("Driver not found");
			}
			catch (SQLException e) {
				// TODO: handle exception
				System.out.println(e);
			}
			
		}

	}

